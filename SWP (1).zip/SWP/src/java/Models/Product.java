/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package Models;

import java.util.*;
import java.lang.*;
public class Product {
    private int productID;
    private String product_name;
    private float price;
    private int quantity;
    private int year;
    private int category_productID;
    private String product_description;
    private int featured;
    private String thumbnail;
    private String brief_information;
    private float original_price;
    private float sale_price;
    private CategoryProduct categoryProduct;

    public Product() {
    }

    public Product(int productID, String product_name, float price, int quantity, int year, int category_productID, String product_description, int featured, String thumbnail, String brief_information, float original_price, float sale_price, CategoryProduct categoryProduct) {
        this.productID = productID;
        this.product_name = product_name;
        this.price = price;
        this.quantity = quantity;
        this.year = year;
        this.category_productID = category_productID;
        this.product_description = product_description;
        this.featured = featured;
        this.thumbnail = thumbnail;
        this.brief_information = brief_information;
        this.original_price = original_price;
        this.sale_price = sale_price;
        this.categoryProduct = categoryProduct;
    }

    public int getProductID() {
        return productID;
    }

    public void setProductID(int productID) {
        this.productID = productID;
    }

    public String getProduct_name() {
        return product_name;
    }

    public void setProduct_name(String product_name) {
        this.product_name = product_name;
    }

    public float getPrice() {
        return price;
    }

    public void setPrice(float price) {
        this.price = price;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public int getCategory_productID() {
        return category_productID;
    }

    public void setCategory_productID(int category_productID) {
        this.category_productID = category_productID;
    }

    public String getProduct_description() {
        return product_description;
    }

    public void setProduct_description(String product_description) {
        this.product_description = product_description;
    }

    public int getFeatured() {
        return featured;
    }

    public void setFeatured(int featured) {
        this.featured = featured;
    }

    public String getThumbnail() {
        return thumbnail;
    }

    public void setThumbnail(String thumbnail) {
        this.thumbnail = thumbnail;
    }

    public String getBrief_information() {
        return brief_information;
    }

    public void setBrief_information(String brief_information) {
        this.brief_information = brief_information;
    }

    public float getOriginal_price() {
        return original_price;
    }

    public void setOriginal_price(float original_price) {
        this.original_price = original_price;
    }

    public float getSale_price() {
        return sale_price;
    }

    public void setSale_price(float sale_price) {
        this.sale_price = sale_price;
    }

    public CategoryProduct getCategoryProduct() {
        return categoryProduct;
    }

    public void setCategoryProduct(CategoryProduct categoryProduct) {
        this.categoryProduct = categoryProduct;
    }

    @Override
    public String toString() {
        return "Product{" + "productID=" + productID + ", product_name=" + product_name + ", price=" + price + ", quantity=" + quantity + ", year=" + year + ", category_productID=" + category_productID + ", product_description=" + product_description + ", featured=" + featured + ", thumbnail=" + thumbnail + ", brief_information=" + brief_information + ", original_price=" + original_price + ", sale_price=" + sale_price + ", categoryProduct=" + categoryProduct + '}';
    }
    
}
