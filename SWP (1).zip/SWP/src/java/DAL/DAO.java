/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAL;

import java.util.*;
import java.lang.*;
import Models.Customer;
import Models.Product;
import Models.SecurityQuestion;
import java.lang.System.Logger;
import java.lang.System.Logger.Level;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;

public class DAO extends DBContext {
    
    public static DAO INSTANCE = new DAO();
    
    public List<Customer> getCustomer() {
        List<Customer> customer = new ArrayList<>();
        try {
            String query = "Select c.customerID, c.first_name, c.last_name,c.phone,c.email,c.address,"
                    + "c.username,c.password,c.dob,c.gender,c.status,c.securityID,sq.security_question,c.securityAnswer \n"
                    + "from Customer c inner join SecurityQuestion sq on c.securityID = sq.securityID";
            PreparedStatement stm = connect.prepareStatement(query);
            ResultSet rs = stm.executeQuery();
            while (rs.next()) {
                SecurityQuestion s = new SecurityQuestion(rs.getInt("securityID"), rs.getString("security_question"));
                Customer c = new Customer(rs.getInt("customerID"),
                        rs.getString("first_name"),
                        rs.getString("last_name"),
                        rs.getString("phone"),
                        rs.getString("email"),
                        rs.getString("address"),
                        rs.getString("username"),
                        rs.getString("password"),
                        rs.getDate("dob"),
                        rs.getBoolean("gender"),
                        rs.getInt("status"),
                        rs.getString("securityAnswer"),
                        s);
                customer.add(c);
            }
        } catch (SQLException e) {
            System.out.println(e);
        }
        return customer;
    }
    
    public Boolean addCustomer(String first_name, String last_name, String phone, String email, String address, String username, String password, Date dob, boolean gender, int status, int securityID, String securityAnswer) {
        try {
            //java.sql.Date sqlDate = new java.sql.Date(dob.getTime());
            SimpleDateFormat mySimpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
            String date1 = mySimpleDateFormat.format(dob);
            String query = "INSERT INTO Customer (first_name, last_name, phone, email, address, username, password, dob, gender, status, "
                    + "securityID, securityAnswer) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement stm = connect.prepareStatement(query);
            stm.setString(1, first_name);
            stm.setString(2, last_name);
            stm.setString(3, phone);
            stm.setString(4, email);
            stm.setString(5, address);
            stm.setString(6, username);
            stm.setString(7, password);
            stm.setDate(8, java.sql.Date.valueOf(date1));
            stm.setBoolean(9, gender);
            stm.setInt(10, status);
            stm.setInt(11, securityID);
            stm.setString(12, securityAnswer);
            stm.executeUpdate();
            return true;
        } catch (Exception e) {
             e.printStackTrace();
        }
        return false;
    }
    
    public int getLastCustomerID() {
        Integer lastCustomerID = null;
        try {
            String query = "SELECT MAX(customerID) AS lastID FROM Customer";
            PreparedStatement stm = connect.prepareStatement(query);
            ResultSet rs = stm.executeQuery();
            if (rs.next()) {
                lastCustomerID = rs.getInt("lastID");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return (lastCustomerID != null) ? lastCustomerID : 9;
    }
    
    public List<String> getSecurityQuestions() {
        List<String> securityQuestions = new ArrayList<>();
        try {
            String query = "SELECT security_question FROM SecurityQuestion";
            PreparedStatement stm = connect.prepareStatement(query);
            ResultSet rs = stm.executeQuery();
            while (rs.next()) {
                String question = rs.getString("security_question");
                securityQuestions.add(question);
            }
        } catch (SQLException e) {
            e.printStackTrace();            
        }
        return securityQuestions;
    }
    
    public int getSecurityQuestionID(String questionText) {
        try {
            String query = "SELECT securityID FROM SecurityQuestion WHERE security_question = ?";
            PreparedStatement stm = connect.prepareStatement(query);
            stm.setString(1, questionText);
            ResultSet rs = stm.executeQuery();
            while (rs.next()) {
                return rs.getInt("securityID");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return -1;
    }
    
    private Date formatDate(String dob) {
        try {
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            return dateFormat.parse(dob);
        } catch (ParseException e) {
            return null;
        }
    }
    
    public static void main(String[] args) {
        DAO d = new DAO();
      // Date dob = d.formatDate("2003-08-11");
      // d.addCustomer("vinh", "nguyen", "01239721210", "vinhnd2003@gmail.com", "Namdinh", "vinh11tdn", "123", dob, true, 1, 1, "What is the name of your first pet?");
//        System.out.println(d.getCustomer());
        System.out.println(d.getSecurityQuestionID("What is the first city you visited?"));
    }
    
}
