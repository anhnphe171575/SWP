/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAL;

import Models.CategoryProduct;
import Models.Product;
import java.util.*;
import java.lang.*;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DAOProduct extends DBContext {
    
    public static DAOProduct INSTANCE = new DAOProduct();
    private int productID;
    private String product_name;
    private float price;
    private int quantity;
    private int year;
    private int category_productID;
    private String product_description;
    private int featured;
    private String thumbnail;
    private String brief_information;
    private float original_price;
    private float sale_price;
    private CategoryProduct categoryProduct;

    public List<Product> getProduct() {
        List<Product> product = new ArrayList();
        try {
            String query = "  select p.productID,p.product_name,p.price,p.quantity,p.year,p.product_description,"
                    + "p.featured,p.thumbnail,p.brief_information,p.original_price,p.sale_price,p.category_productID,"
                    + "cp.category_name,cp.category_description from Product p inner join CategoryProduct cp "
                    + "on p.category_productID = cp.category_productID";
            PreparedStatement stm = connect.prepareStatement(query);
            ResultSet rs = stm.executeQuery();
            while (rs.next()) {
                CategoryProduct cp = new CategoryProduct(rs.getInt("category_productID"),
                        rs.getString("category_name"), rs.getString("category_description"));
                Product p = new Product(rs.getInt("productID"),
                        rs.getString("product_name"),
                        rs.getFloat("price"),
                        rs.getInt("quantity"),
                        rs.getInt("year"),
                        rs.getInt("category_productID"),
                        rs.getString("product_description"),
                        rs.getInt("featured"),
                        rs.getString("thumbnail"),
                        rs.getString("brief_information"),
                        rs.getFloat("original_price"),
                        rs.getFloat("sale_price"),
                        cp);
                product.add(p);
            }
        } catch (SQLException e) {
            System.out.print(e);
        }
        return product;
    }
    public static void main(String[] args) {
        DAOProduct d = new DAOProduct();
        List<Product> p = d.getProduct();
        for(Product product:p){
            System.out.println(product.toString());
        }
    }
}
